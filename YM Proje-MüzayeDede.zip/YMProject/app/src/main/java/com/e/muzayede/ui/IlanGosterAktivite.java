package com.e.muzayede.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.ActiveUser;
import com.e.muzayede.network.forum.Ilan;
import com.e.muzayede.network.forum.Teklifler;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Map;

public class IlanGosterAktivite extends AppCompatActivity {
    private final static String TAG="IlanGosterAktivite.java";
    private Context mContex;
    private TextView postTitle;
    private ImageView flag;
    private ImageView postPic;
    private TextView textIcerik;
    private EditText addComment;
    private ImageButton saveComment;  //cames from the another card
    private ImageView nextPic;
    private ImageView imageUser;
    private TextView userName;
   // private ImageView imageViewTeklif;
    private TextView textViewTeklif;
    private TextView textViewLike;
    private LinearLayout postInfo;
    private  ImageView imageViewComment;
    private TextView textViewComment;
    private ImageView imageViewFav;
    private TextView textViewFav;
    private RelativeLayout userCont;
    private ImageView addCommentButton;
    private RecyclerView commentRecyclerView;
    private ArrayList<String>  commentDataCometoOutList;
    private CommentRVAdapter CommentRVAdapter;
    private RelativeLayout likeContainer;
    private EditText tutarText;
    private TextView textViewAddDate;
    private ActiveUser activeUser = ActiveUser.getInstance();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private Ilan ilan = new Ilan();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_post_page);
        ilan.setId(getIntent().getStringExtra("ILAN_ID"));
        getIlan(ilan.getId());
        textViewAddDate = findViewById(R.id.textViewAddDate);
        tutarText = findViewById(R.id.tutarText);
        likeContainer = findViewById(R.id.likeContainer);
            postTitle = findViewById(R.id.postTitle);
            flag = findViewById(R.id.flag);
            postPic = findViewById(R.id.postPic);
            textIcerik = findViewById(R.id.textIcerik);
            nextPic = findViewById(R.id.nextPic);
            textIcerik.setMovementMethod(new ScrollingMovementMethod());
            postInfo = findViewById(R.id.postInfo);
            mContex = IlanGosterAktivite.this;
            userName = findViewById(R.id.userName);
        //imageViewTeklif = findViewById(R.id.imageViewLike);
        textViewTeklif = findViewById(R.id.textViewTeklif);
        imageViewComment = findViewById(R.id.imageViewComment);
        textViewComment = findViewById(R.id.textViewComment);
        imageViewFav = findViewById(R.id.imageViewFav);
        textViewFav = findViewById(R.id.textViewFav);
        addCommentButton = findViewById(R.id.addCommentButton);
       commentRecyclerView = findViewById(R.id.commentRecyclerView);
        commentRecyclerView.setHasFixedSize(true);
        commentRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        commentDataCometoOutList = new ArrayList<>();
        commentDataCometoOutList.add(0,"ilk yorum ");
        commentDataCometoOutList.add(1,"yorum yorum");
        commentDataCometoOutList.add(2,"Lorem ipsum dolarsitamet");

        CommentRVAdapter = new CommentRVAdapter(this, commentDataCometoOutList);
        commentRecyclerView.setAdapter(CommentRVAdapter);
        System.out.println("IlanGoster Id : " + ilan.getId());

///////////// go user page start---
     userCont = findViewById(R.id.userCont);
     userCont.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {

             Toast.makeText(IlanGosterAktivite.this, "kullanıcıya git", Toast.LENGTH_SHORT).show();
             Intent intent = new Intent(getApplicationContext(), AnaSayfaAkisAktivite.class);
             startActivity(intent);


         }
     });
 ///////////// go user page end




    tutarText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //todo girilen tutarı intent ile al üeri tabanına aktar
                Toast.makeText(IlanGosterAktivite.this, "tutar eklendi", Toast.LENGTH_SHORT).show();
            }
        });


    textViewTeklif.setOnClickListener(new View.OnClickListener() { //Teklif ve butonu
        @Override
        public void onClick(View v) {
            if(Integer.parseInt(activeUser.getTip()) > 2) {
                Double verilenTeklif = Double.parseDouble(tutarText.getText().toString());
                db.collection("ilanlar").document(ilan.getId()).collection("teklifler").orderBy("zaman", Query.Direction.DESCENDING).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        ilan.teklifler.clear();
                        int i=0;
                        for(QueryDocumentSnapshot doc: queryDocumentSnapshots){
                            ilan.teklifler.add(doc.toObject(Teklifler.class));

                        }
                        bilgileriYukle();
                    }
                });
                if (verilenTeklif > ilan.teklifler.get(0).getFiyat()){
                    ilan.teklifler.get(0).setFiyat(verilenTeklif);
                    ilan.teklifler.get(0).setTeklifVeren(activeUser.getId());
                    //Uygun teklif ekleniyor.
                    db.collection("ilanlar").document(ilan.getId()).collection("teklifler").add(ilan.getTeklifler().get(0).getMap()).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {

                        }
                    });
                }
                //todo veritabanı bağlaması burada yapılacak


                // todo if teklif == 0 veya !>= mevcut teklif ise kaydetme, uyarı mesajı ver
                // girilen teklif mevcut tekliften büyük olmalı veya boş geçilmemeli şeklinde.
                Toast.makeText(IlanGosterAktivite.this, "teklif verildi", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(IlanGosterAktivite.this,"Teklif vermebilmeniz icin uye olmalisiniz", Toast.LENGTH_LONG).show();
            }
        }
    });



        nextPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(IlanGosterAktivite.this, "Sonraki görsele geç", Toast.LENGTH_SHORT).show();
            // todo nextPicture method

            }
        });


        flag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // bildirimler ve şikayetler
                Toast.makeText(IlanGosterAktivite.this, "flag clicked", Toast.LENGTH_SHORT).show();
/////////////eklenen

                        PopupMenu popUp = new PopupMenu(mContex, v);
                        MenuInflater inflater = popUp.getMenuInflater();
                        inflater.inflate(R.menu.post_flag_menu,popUp.getMenu());
                        popUp.show();


                        popUp.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {

                                switch (item.getItemId()){

                                    case R.id.report:

                                        Toast.makeText(mContex, "Şikayet edildi", Toast.LENGTH_SHORT).show();

                                        return true;

                                    default:
                                        return false;
                                }




                            }
                        });






/////////////eklenen
            }
        });


        addCommentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                       //todo
                Toast.makeText(IlanGosterAktivite.this, "yorum eklendi", Toast.LENGTH_SHORT).show();
                // Open edit text field, like button animation
                // save comment Image kullanılacak fakat bu comment add layoutundan gelecek. recycler view olarak kullanılmalı
            }
        });

    postInfo.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {


            Toast.makeText(IlanGosterAktivite.this, "Teklif Verilecek new activity", Toast.LENGTH_SHORT).show();
        }
    });




    } // oncreate end

    public void nextPicture(View view){

        Toast.makeText(this, "sonraki görseli çek", Toast.LENGTH_SHORT).show();
    }
    public void bilgileriYukle(){
        try{
            userName.setText(ilan.urun.user.getAdSoyad());
            postTitle.setText(ilan.getBaslik());
            textIcerik.setText(ilan.getIcerik());
            //Picasso.get().load(currentIlan.urun.getResim()).into(holder.imageViewPostPic);
            System.out.println("ilan goster resimid " + ilan.urun.getResim());
            Picasso.get().load(ilan.urun.getResim()).into(postPic);
            textViewAddDate.setText(ilan.getBaslangicStr());
            System.out.println("Son teklif " + ilan.teklifler.get(0).getFiyat());
            tutarText.setText(ilan.teklifler.get(0).getFiyat().toString());

        }catch (Exception e){
            System.out.println(e.getLocalizedMessage());
        }

        //System.out.println("teklifler " + Double.toString(ilan.getTeklifler().get(0).getFiyat()));


    }
// teklif ver fonksiyonu Relative Layout içerisinde aktif

    public void getIlan(String ilanId){
        db.collection("ilanlar").document(ilanId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    ilan = task.getResult().toObject(Ilan.class);
                    ilan.setId(task.getResult().getId());
                    db.collection("users").document(ilan.getIlanverenId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                            if(task.isSuccessful()) {
                                Map<String, Object> data = task.getResult().getData();
                                ilan.urun.user.setAdSoyad((String) data.get("adSoyad"));
                            }
                            bilgileriYukle();
                        }
                    });
                    db.collection("urunler").document(ilan.getUrunId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                            if(task.isSuccessful()){
                                Map<String, Object> data = task.getResult().getData();
                                ilan.urun.setResim((String) data.get("resim"));
                                System.out.println("ilan goster ici " + ilan.urun.getResim());
                            }
                            bilgileriYukle();
                        }
                    });
                    //Teklifleri al.
                    System.out.println("teklifler icin " + ilanId);
                    db.collection("ilanlar").document(ilanId).collection("teklifler").orderBy("zaman", Query.Direction.DESCENDING).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull @NotNull Task<QuerySnapshot> task) {
                            if(task.isSuccessful()){
                                int i = 0;
                                for(QueryDocumentSnapshot doc:task.getResult()){
                                    ilan.teklifler.add(doc.toObject(Teklifler.class));
                                    System.out.println("deneme" +  doc.getData());
                                    i++;
                                }
                                System.out.println("Teklif boyutu ve i " + ilan.teklifler.size() + " " + i);
                                bilgileriYukle();
                            }
                        }
                    });
                }
                bilgileriYukle();
            }
        });
    }



} //class end