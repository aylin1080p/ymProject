package com.e.muzayede.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.Kategoriler;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class KategoriSecAktivite extends AppCompatActivity {

    private EditText kategoriText;
    private Button saveButton;
    private Button altkategorimiButton;
    private Boolean altKategorimi = false;
    private ListView kategoriListesi;
    private ArrayList<Kategoriler> categories = new ArrayList<>();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private static final String TAG = "KategoriEkleAktivite";
    private Kategoriler kategori;
    private String kategoritext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_choose);
        altkategorimiButton = findViewById(R.id.altkategorimi);
        kategoriListesi = findViewById(R.id.kategoriListesi);
        getCategories();
        kategoriText = findViewById(R.id.addTitle);
        /*altkategorimiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                altKategorimi = true;
                Toast.makeText(KategoriSecAktivite.this, "Üst Kategoriler Getiriliyor", Toast.LENGTH_SHORT).show();
                KategoriListeleAdapter kategoriListeleAdapter = new KategoriListeleAdapter(categories, KategoriSecAktivite.this);
                kategoriListesi.setAdapter(kategoriListeleAdapter);
            }
        });*/

        kategoriListesi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //kategoritext = kategoriText.getText().toString();
                //categories.get(position).getId();
                System.out.println("Secilen" + categories.get(position).getAdi());
                /*if(!kategoritext.equals("")) {
                    //TODO Ust kategorinin alti yoksa eklendigi icin onun soncocugu true dan false olmali
                    kategori = new Kategoriler(0, kategoritext, categories.get(position).getId(), "", "",0, true);
                    kategori.olustur();
                    Toast.makeText(KategoriSecAktivite.this, kategoritext + " kategori eklendi", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(KategoriSecAktivite.this, AnaSayfaAkisAktivite.class);
                    startActivity(intent);
                    finish();
                }*/
                Intent intent = new Intent(KategoriSecAktivite.this, IlanEkleAktivite.class);
                intent.putExtra("CATEGORY_ID", categories.get(position).getId());
                startActivity(intent);
                finish();
            }
        });
    }

    public void ekleDefaultKategoriler(){
            List<Kategoriler> liste = new ArrayList<Kategoriler>(){{
                add(new Kategoriler(0,"Dizüstü",1,"","",0,true));
                add(new Kategoriler(0, "Masaüstü", 1, "", "",0,true));
                add(new Kategoriler(0, "Table", 1, "", "",0,true));
                add(new Kategoriler(0, "Monitör", 1, "", "",0,true));
                add(new Kategoriler(0, "Telefon", 2, "", "",0,true));
                add(new Kategoriler(0, "Yedek Parça", 2, "", "",0,true));
                add(new Kategoriler(0, "Giyilebilir Teknoloji", 2, "", "",0,true));
                add(new Kategoriler(0, "Dijital Fotoğraf Makinesi", 3, "", "",0,true));
                add(new Kategoriler(0, "Lens Aksesuarları", 3, "", "",0,true));
                add(new Kategoriler(0, "Analog Fotoğraf Makinesi", 3, "", "",0,true));
                add(new Kategoriler(0, "Televizyon", 4, "", "",0,true));
                add(new Kategoriler(0, "Sinema Sistemleri", 4, "", "",0,true));
                add(new Kategoriler(0, "Müzik Sistemleri", 4, "", "",0,true));
                add(new Kategoriler(0, "Duvar Saati", 5, "", "",0,true));
                add(new Kategoriler(0, "Kol Saati", 5, "", "",0,true));
                add(new Kategoriler(0, "Masa Saati", 5, "", "",0,true));
                add(new Kategoriler(0, "Cep Saati", 5, "", "",0,true));
                add(new Kategoriler(0, "Makine", 6, "", "",0,true));
                add(new Kategoriler(0, "Mobilya", 6, "", "",0,true));
                add(new Kategoriler(0, "Oyuncak", 6, "", "",0,true));
                add(new Kategoriler(0, "Enstrüman", 6, "", "",0,true));
            }};
            for (int i=0;i<liste.size();i++)
                liste.get(i).olustur();
        }




    public void getCategories() {
        //Sadece Ana kategorileri Alfabetik olarak siralar.
        db.collection("categories").whereEqualTo("ustId",0).orderBy("adi", Query.Direction.ASCENDING).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                Log.d(TAG, "Query onComlete" );
                if(task.isSuccessful()){
                    Log.d(TAG,"Query onComplete and task Successful");
                    for(QueryDocumentSnapshot document: task.getResult() ) {
                        categories.add(document.toObject(Kategoriler.class));
                    }
                    writeCategories();
                    KategoriListeleAdapter kategoriListeleAdapter = new KategoriListeleAdapter(categories, KategoriSecAktivite.this);
                    kategoriListesi.setAdapter(kategoriListeleAdapter);
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG, "Kategori listesi cekilemedi.");
            }
        });

    }
    public void writeCategories(){
        Log.d(TAG, String.valueOf(categories.size()));
        for(int i=0; i<categories.size();i++){
            //categories.get(i).getAdi()
            Log.d(TAG, categories.get(i).getAdi());
        }
    }

}