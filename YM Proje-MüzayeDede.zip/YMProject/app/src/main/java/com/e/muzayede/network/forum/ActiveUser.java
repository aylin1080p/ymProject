package com.e.muzayede.network.forum;

public class ActiveUser {
    private String id; //Firebase user id
    private String email;
    private String tip; //Kullanici tipi
    private static ActiveUser instance;
    private ActiveUser(){

    }

    public static ActiveUser getInstance(){
        if(instance == null) {
            instance = new ActiveUser();
        }
        return instance;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }
}
