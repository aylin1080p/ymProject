package com.e.muzayede.ui;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.Kategoriler;

import java.util.ArrayList;

public class KategoriListeleAdapter extends ArrayAdapter<Kategoriler> {
    private ArrayList<Kategoriler> kategoriler;
    private Activity context;
    public KategoriListeleAdapter(ArrayList<Kategoriler> kategoriler, Activity context){
        super(context, R.layout.adapter_kategori_listele, kategoriler);
        this.kategoriler = kategoriler;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = context.getLayoutInflater();
        View customView = layoutInflater.inflate(R.layout.adapter_kategori_listele, null, true);
        TextView nameView = customView.findViewById(R.id.customTextView);
        nameView.setText(kategoriler.get(position).getAdi());
        return customView;
    }
}
