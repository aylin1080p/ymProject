package com.e.muzayede.network.forum;

import android.view.ScaleGestureDetector;

import org.threeten.bp.OffsetDateTime;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Ilan {

    private String id;
    private String baslik;
    private String icerik;
    private String ilanverenId;
    public Urunler urun = new Urunler();
    //private OffsetDateTime bas;
    private Date baslangic;
    private Date bitis;
    public ArrayList<Teklifler> teklifler = new ArrayList<Teklifler>();
    private String urunId;
    private SimpleDateFormat formatter = new SimpleDateFormat("hh:mm dd/MM/yy");
    public Ilan() {
    }

    public Ilan(String id, String baslik, String icerik, String ilanverenId, Date baslangic, Date bitis) {
        this.id = id;
        this.baslik = baslik;
        this.icerik = icerik;
        this.ilanverenId = ilanverenId;
        this.baslangic = baslangic;
        this.bitis = bitis;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getIcerik() {
        return icerik;
    }

    public void setIcerik(String icerik) {
        this.icerik = icerik;
    }

    public String getIlanverenId() {
        return ilanverenId;
    }

    public void setIlanverenId(String ilanverenId) {
        this.ilanverenId = ilanverenId;
    }

    public Urunler getUrun() {
        return urun;
    }

    public void setUrun(Urunler urun) {
        this.urun = urun;
    }

    public Date getBaslangic() {
        return baslangic;
    }
    public String getBaslangicStr(){
        return formatter.format(baslangic);
    }

    public void setBaslangic(Date baslangic) {
        this.baslangic = baslangic;
    }

    public Date getBitis() {
        return bitis;
    }

    public void setBitis(Date bitis) {
        this.bitis = bitis;
    }

    public ArrayList<Teklifler> getTeklifler() {
        return teklifler;
    }

    public void setTeklifler(ArrayList<Teklifler> teklifler) {
        this.teklifler = teklifler;
    }

    public String getUrunId() {
        return urunId;
    }

    public void setUrunId(String urunId) {
        this.urunId = urunId;
    }

}
