package com.e.muzayede.network.forum;


import com.google.firebase.firestore.FieldValue;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Teklifler {
    private String id;
    private String teklifVeren;
    private Double fiyat;
    private Date zaman;

    public Teklifler() {
    }

    public Teklifler(String id, String teklifVeren, Double fiyat, Date zaman) {
        this.id = id;
        this.teklifVeren = teklifVeren;
        this.fiyat = fiyat;
        this.zaman = zaman;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTeklifVeren() {
        return teklifVeren;
    }

    public void setTeklifVeren(String teklifVeren) {
        this.teklifVeren = teklifVeren;
    }

    public Double getFiyat() {
        return fiyat;
    }

    public void setFiyat(Double fiyat) {
        this.fiyat = fiyat;
    }

    public Date getZaman() {
        return zaman;
    }

    public void setZaman(Date zaman) {
        this.zaman = zaman;
    }

    public Map<String, Object> getMap(){
        Map<String, Object> sonuc = new HashMap<String, Object>();
        sonuc.put("id", this.id);
        sonuc.put("teklifVeren", this.teklifVeren);
        sonuc.put("fiyat", this.fiyat);
        sonuc.put("zaman", FieldValue.serverTimestamp());
        return sonuc;
    }
}
