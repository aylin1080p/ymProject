package com.e.muzayede.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.Kategoriler;

import java.util.ArrayList;
import java.util.List;

import static android.view.View.INVISIBLE;

public class ForumCategoryAdapter
        extends RecyclerView.Adapter<ForumCategoryAdapter.CategoryViewHolder> {

    private List<Kategoriler> allCategories = new ArrayList<>();
    private List<Kategoriler> data = new ArrayList<>();
    private LayoutInflater layoutInflater;
    private ForumCategoryAdapterListener adapterListener;

    public interface ForumCategoryAdapterListener{
           void sendCurrentId (int id, int parentId);
           void goToPosts (int id);

    }

    // constructor
    public ForumCategoryAdapter(Context context, List<Kategoriler> allCategories, ForumCategoryAdapterListener listener) {
        this.adapterListener = listener;
        this.layoutInflater = (LayoutInflater) context.getSystemService(
                Context.LAYOUT_INFLATER_SERVICE);
        this.allCategories = allCategories;
    }

    // Provide a reference to the views for each row
    public static class CategoryViewHolder extends RecyclerView.ViewHolder {

        private CardView categoryCard;
        private ImageView categoryImage;
        private TextView categoryTitle;
        private TextView categoryDescription;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            categoryCard = itemView.findViewById(R.id.categoryCard);
            categoryImage = itemView.findViewById(R.id.categoryImage);
            categoryTitle = itemView.findViewById(R.id.categoryTitle);
            categoryDescription = itemView.findViewById(R.id.categoryDescription);
        }
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View categoryRow = this.layoutInflater.inflate(
                R.layout.row_category, parent, false);
        return new CategoryViewHolder(categoryRow);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        Kategoriler currentKategori = data.get(position);

        // set image
        if (currentKategori.getResimId() == 0) {  // no image
            holder.categoryImage.setVisibility(INVISIBLE);
        } else {
            holder.categoryImage.setVisibility(View.VISIBLE);
            holder.categoryImage.setImageResource(currentKategori.getUstId());
        }

        // set title (category name)
        holder.categoryTitle.setText(currentKategori.getAdi());

        // set description
        holder.categoryDescription.setText(currentKategori.getAciklama());

        // clicking on category card takes you to children categories
        holder.categoryCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isLastChild = currentKategori.isSonCocuk();
                if (isLastChild) {
                    adapterListener.goToPosts(currentKategori.getId());
                } else {
                    setCurrentData(currentKategori.getId());
                    adapterListener.sendCurrentId(currentKategori.getId(), currentKategori.getUstId());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setCurrentData(int parentId) {
        this.data = getChildCategoriesOfParent(allCategories, parentId);
        notifyDataSetChanged();
    }

    private List<Kategoriler> getChildCategoriesOfParent(List<Kategoriler> categories, int parentId) {
        ArrayList<Kategoriler> childCategories = new ArrayList<>();
        for (Kategoriler kategori : categories) {
            if (kategori.getUstId() == parentId) {
                childCategories.add(kategori);
            }
        }
        return childCategories;
    }
}

