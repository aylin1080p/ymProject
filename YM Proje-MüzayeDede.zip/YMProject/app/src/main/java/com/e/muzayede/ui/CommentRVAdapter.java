package com.e.muzayede.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.e.muzayede.R;

import java.util.List;

public class CommentRVAdapter extends RecyclerView.Adapter<CommentRVAdapter.CardViewTasarimNesneleri> {
    private Context mContext;
    private List<String> commentDataCometoOutList;

    public CommentRVAdapter(Context mContext, List<String> commentDataCometoOutList) {
        this.mContext = mContext;
        this.commentDataCometoOutList = commentDataCometoOutList;
    }

    @NonNull
    @Override
    public CardViewTasarimNesneleri onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // design inflate
        View itemView = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.comment_card,parent,false);


        return new CardViewTasarimNesneleri(itemView);
    }

    public class  CardViewTasarimNesneleri extends RecyclerView.ViewHolder{
// yorum card viewundaki nesleeri tanımlamalısın burada

        public TextView commentTextView;
        public ImageView profilPic;
        public TextView userName;
        public TextView addedDate;


        public CardViewTasarimNesneleri(View view){
            super(view);
            commentTextView = view.findViewById(R.id.commentTextView);
            profilPic = view.findViewById(R.id.profilPic);
            userName = view.findViewById(R.id.userName);
            addedDate = view.findViewById(R.id.addedDate);



        }

    }



    @Override
    public void onBindViewHolder(@NonNull CardViewTasarimNesneleri holder, int position) {
        String userName = commentDataCometoOutList.get(position);
        String commentText = commentDataCometoOutList.get(position);
        String addedDate = commentDataCometoOutList.get(position);

        holder.addedDate.setText(addedDate);
        holder.commentTextView.setText(commentText);
        holder.userName.setText(userName);


        holder.userName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext, "go to User Page", Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return commentDataCometoOutList.size();
    }



}
