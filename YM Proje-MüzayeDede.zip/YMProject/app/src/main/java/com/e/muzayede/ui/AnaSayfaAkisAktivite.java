package com.e.muzayede.ui;


import android.animation.Animator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.ActiveUser;
import com.e.muzayede.network.forum.AktifKullanici;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class AnaSayfaAkisAktivite extends AppCompatActivity
        implements ForumFragment.ForumFragmentListener {


    private BottomNavigationView bottomNav;
    private ProfileFragment profileFragment;
    private ForumFragment forumFragment;
    private NotificationsFragment notificationsFragment;
    private RelativeLayout searchBarContainer;
    private View executeSearchButton;
    private EditText searchInput;
    private ImageView openSearchButton;
    private View closeSearchButton;
    private ImageButton goToMainActivityButton;
    private AktifKullanici aktifKullanici = AktifKullanici.getInstance();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social);
        // buttons and views
        goToMainActivityButton = findViewById(R.id.changeSocialToMainButton);
        openSearchButton = findViewById(R.id.openSearchButton);
        closeSearchButton = findViewById(R.id.closeSearchButton);
        searchBarContainer = findViewById(R.id.searchBarContainer);
        executeSearchButton = findViewById(R.id.executeSearchButton);
        searchInput = findViewById(R.id.searchInput);

        // social to main button
        goToMainActivityButton.setOnClickListener((View v) -> goToMainActivity());

        // bottom navigation operation variables
        bottomNav = findViewById(R.id.bottomNavigationViewSocial);

        // react to clicks on the bottom navigation items
        bottomNav.setOnNavigationItemSelectedListener(bottomNavListener);

        // SocialActivity ilk acildiginda, ForumFragment'a git
        bottomNav.setSelectedItemId(R.id.socialNavForum);

        // Arama sekmesi acma ve kapama
        openSearchButton.setOnClickListener(view -> {
            openSearchBar();
            showCategoryRecyclerView();
        });
        closeSearchButton.setOnClickListener(view -> {
            int res = categoryNavigationGoBack();
            if(res == 0){
                closeSearchBar();
            }
        });
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private void showCategoryRecyclerView() {
        if (forumFragment != null) {
            forumFragment.showCategoryRecyclerView();
        }
    }

    private int categoryNavigationGoBack() {
        if (forumFragment != null) {
           return forumFragment.categoryNavigationGoBack();
        } else {
            return 0;
        }
    }

    private void openSearchBar() {
        searchInput.setText("");
        searchBarContainer.setVisibility(VISIBLE);
        Animator animator = ViewAnimationUtils.createCircularReveal(
                searchBarContainer,
                (openSearchButton.getRight() + openSearchButton.getLeft()) / 2,
                (openSearchButton.getTop() + openSearchButton.getBottom()) / 2,
                0f,
                searchBarContainer.getWidth()
        );
        animator.setDuration(300);
        animator.start();

        // also prevent Social -> Main clicks
        goToMainActivityButton.setOnClickListener(null);
    }

    private void closeSearchBar() {
        // re-enable Social -> Main click
        goToMainActivityButton.setOnClickListener((View v) -> goToMainActivity());

        // animations
        Animator animator = ViewAnimationUtils.createCircularReveal(
                searchBarContainer,
                (openSearchButton.getRight() + openSearchButton.getLeft()) / 2,
                (openSearchButton.getTop() + openSearchButton.getBottom()) / 2,
                searchBarContainer.getWidth(),
                0f
        );

        animator.setDuration(300);
        animator.start();

        animator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) { }

            @Override
            public void onAnimationEnd(Animator animator) {
                searchBarContainer.setVisibility(View.INVISIBLE);
                searchInput.setText("");
                animator.removeAllListeners();
            }

            @Override
            public void onAnimationCancel(Animator animator) { }

            @Override
            public void onAnimationRepeat(Animator animator) { }
        });

        // close keyboard if open
        hideKeyboard(this);
    }

    private void goToMainActivity () {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        finish();
    }

     private BottomNavigationView.OnNavigationItemSelectedListener bottomNavListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch (menuItem.getItemId()){
                case R.id.socialNavProfile:
                    openSearchButton.setVisibility(GONE);
                    forumFragment = null;
                    notificationsFragment = null;
                    if (profileFragment == null) {
                        profileFragment = new ProfileFragment();
                    }
                    setFragment(profileFragment);
                    return true;  // true makes the item look "selected"
                case R.id.socialNavForum:
                    openSearchButton.setVisibility(VISIBLE);
                    profileFragment = null;
                    notificationsFragment = null;
                    if (forumFragment == null) {
                        forumFragment = new ForumFragment();
                    }
                    setFragment(forumFragment);
                    return true;
                case R.id.socialNavNotifications:
                    openSearchButton.setVisibility(GONE);
                    profileFragment = null;
                    forumFragment = null;
                    if (notificationsFragment == null) {
                        notificationsFragment = new NotificationsFragment();
                    }
                    setFragment(notificationsFragment);
                    return true;
                default:
                    return false;
            }
        }
    };

    private void setFragment (Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.socialActFragmentContainer, fragment)
                // .addToBackStack(fragment.getTag())
                .commit();
    }

    @Override
    public void closeSearchBarFromFragment() {
        closeSearchBar();
    }

    @Override
    public void onAttachFragment(@NonNull Fragment childFragment) {
        if (childFragment instanceof ForumFragment) {
            ForumFragment fragment = (ForumFragment) childFragment;
            fragment.setForumFragmentListener(this);
        }
    }
}
