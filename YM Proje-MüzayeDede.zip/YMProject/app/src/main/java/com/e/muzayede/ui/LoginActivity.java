package com.e.muzayede.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.AktifKullanici;
import com.e.muzayede.network.forum.ActiveUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

public class LoginActivity extends AppCompatActivity {

    private Button buttonLogin,btnSignup,buttonLoginn,buttonLoginwithout;
    private TextView textView5;
    private TextView username,password;
    private SharedPreferences sp;
    private SharedPreferences.Editor editor;
    private Button button3;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private FirebaseUser firebaseUser;
    private AktifKullanici aktifKullanici = AktifKullanici.getInstance();
    private ActiveUser activeUser = ActiveUser.getInstance();
    final String TAG = "LoginActivity";
    private Long tip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        button3 = findViewById(R.id.addPostFabButton3);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        sp = getSharedPreferences("GirisBilgi",MODE_PRIVATE);
        editor = sp.edit();
        firebaseUser = firebaseAuth.getCurrentUser();
        if (firebaseUser !=null) {
            Log.d(TAG, "Kullanici daha once giris yapmis  " + firebaseUser.getUid() );
            aktifKullanici.setEmail(firebaseUser.getEmail());
            girisIslemleri(firebaseUser.getUid());
        }
        //textView5 == Şifremi unuttum.
        textView5 = findViewById(R.id.textView5);
        textView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //todo şifre güncelleme işlemleri

                Toast.makeText(LoginActivity.this, "şifre güncelleme etkinlikleri", Toast.LENGTH_SHORT).show();
            }
        });
        buttonLoginwithout = findViewById(R.id.buttonLoginwithout);
        buttonLoginwithout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activeUser.setTip("1");
                System.out.println("Uyeolmadan giris tiklandi.");
                Intent intent = new Intent(com.e.muzayede.ui.LoginActivity.this, AnaSayfaAkisAktivite.class);
                startActivity(intent);
            }
        });



        buttonLogin=(Button)findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emailText = username.getText().toString();
                String passwordText = password.getText().toString();
                if(emailText.length()>0 && passwordText.length()>0) {
                  firebaseAuth.signInWithEmailAndPassword(emailText,passwordText).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            Toast.makeText(LoginActivity.this,"Hoşgeldiniz.", Toast.LENGTH_LONG).show();
                            firebaseUser = firebaseAuth.getCurrentUser();
                            girisIslemleri(firebaseUser.getUid());
                            //TODO  tip'e göre farklı activitelere mi gönderilecek? yoksa her aktivite tipe göre farklılaşabilecek mi?
                            Intent intent = new Intent(com.e.muzayede.ui.LoginActivity.this, AnaSayfaAkisAktivite.class);
                            startActivity(intent);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(LoginActivity.this,"İlgili kullanıcı adı ve/veya şifre bulunmadı", Toast.LENGTH_LONG).show();
                        }
                    });
                }
                /* Firebase öncesi
                if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin123") ) {

                editor.putString("username",username.getText().toString());
                editor.putString("password",password.getText().toString());
                editor.commit();


                    Toast.makeText(LoginActivity.this, "admin girişi yapılıyor", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(com.e.muzayede.ui.LoginActivity.this, AnaSayfaAkisAktivite.class);
                    startActivity(intent);
                    // admin için tüm sekmeler aktif olmalı bir alt yöneticide yönetici ekle butonu görünür olmayacak
                }

                    else if (username.getText().toString().equals("") && password.getText().toString().equals("")){

                    Toast.makeText(LoginActivity.this, "Kullanıcı adı ve şifre girin veya üye olmadan devam edin", Toast.LENGTH_SHORT).show();

                }

                 //   else if (){
                //   todo yanlış şifre veya kullanıcı adı girilirse vt eşleşmesi kontrol edilmeli
                //
                //   }


                        else if (username.getText().toString().equals("subadmin") && password.getText().toString().equals("subadmin123") ) {

                    editor.putString("username",username.getText().toString());
                    editor.putString("password",password.getText().toString());
                    editor.commit();


                    Toast.makeText(LoginActivity.this, "alt yönetici girişi yapılıyor", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(com.e.muzayede.ui.LoginActivity.this, AnaSayfaAkisAktivite.class);
                    startActivity(intent);
                    //todo setvisibilty for category button






                    // admin için tüm sekmeler aktif olmalı bir alt yöneticide yönetici ekle butonu görünür olmayacak
                }




                */

            }
        });


        //UyeOkAktivite ye git.
        btnSignup=(Button)findViewById(R.id.btnSignup);

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(com.e.muzayede.ui.LoginActivity.this, UyeOlAktivite.class);
                startActivity(intent);
            }
        });

    }
    private void girisIslemleri(String userid){
        aktifKullanici.setId(userid);
        System.out.println("1 Giris Islemleri " + aktifKullanici.getId() + " <+> " + userid);
        //Log.d(TAG, "girisIslemleri " + aktifKullanici.getId() + " <+> " + userid);
        DocumentReference docRef = firestore.collection("users").document(userid);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    DocumentSnapshot document = task.getResult();
                    if(document.exists()){
                        System.out.println("2 DocumentSnapshoot datasi:  " + document.getData());
                        //Log.d(TAG, "DocumentSnapshoot datasi:  " + document.getData());
                        aktifKullanici = document.toObject(AktifKullanici.class);
                        System.out.println("2 1 onComplete: " + aktifKullanici.getEmail() + " tip " + aktifKullanici.getTipString());
                        activeUser.setEmail(aktifKullanici.getEmail());
                        activeUser.setTip(aktifKullanici.getTipString());
                        //Log.d(TAG, "onComplete: " + aktifKullanici.getEmail());
                    } else {
                        aktifKullanici.bosOlustur();
                        Log.d(TAG, "Users collection eksik " + userid);
                    }
                    activeUser.setId(aktifKullanici.getId());
                }
            }
        });

        /*CollectionReference colRef = firestore.collection("users");
        colRef.document(userid).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                System.out.println(documentSnapshot.exists());
                if(documentSnapshot.exists()) {
                    aktifKullanici = documentSnapshot.toObject(AktifKullanici.class);
                    Log.d(TAG, "Kullanici id  " + aktifKullanici.getId());
                    Log.d(TAG, "Kullanici emaili " + aktifKullanici.getEmail());
                    Log.d(TAG, "Kullanici tipi " + aktifKullanici.getTip().toString());
                } else {
                    aktifKullanici.olustur(firebaseUser.getUid(), firebaseUser.getEmail());
                    Log.d(TAG, "Daha once giris yapmis kullanicinin bilgileri eksik");
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                Log.d(TAG, "Kullanici veritabaninda bilgi bulunamamistir.");
            }
        });*/
        /*colRef.document(userid).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    System.out.println("EVeettt");
                } else {
                    System.out.println("aranan bulunmadi.");
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                System.out.println("Hata olustu");
            }
        });*/
        Log.d(TAG, "giris islemleri bitti.");
        /*colRef.document(userid).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                System.out.println(documentSnapshot.exists());
                if(documentSnapshot.exists()) {
                    aktifKullanici = documentSnapshot.toObject(AktifKullanici.class);
                    Log.d(TAG, "Kullanici id  " + aktifKullanici.getId());
                    Log.d(TAG, "Kullanici emaili " + aktifKullanici.getEmail());
                    Log.d(TAG, "Kullanici tipi " + aktifKullanici.getTip().toString());
                } else {
                    aktifKullanici.olustur(firebaseUser.getUid(), firebaseUser.getEmail());
                    Log.d(TAG, "Daha once giris yapmis kullanicinin bilgileri eksik");
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                Log.d(TAG, "Kullanici veritabaninda bilgi bulunamamistir.");
            }
        });*/
        Intent intent = new Intent(com.e.muzayede.ui.LoginActivity.this, AnaSayfaAkisAktivite.class);
        startActivity(intent);
        finish();
    }
}
