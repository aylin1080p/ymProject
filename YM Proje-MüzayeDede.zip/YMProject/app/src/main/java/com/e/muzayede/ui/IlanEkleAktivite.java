package com.e.muzayede.ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.ActiveUser;
import com.e.muzayede.network.forum.AktifKullanici;
import com.e.muzayede.network.forum.Ilan;
import com.e.muzayede.network.forum.Teklifler;
import com.e.muzayede.network.forum.Urunler;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.common.base.MoreObjects;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.HashMap;
import java.util.UUID;

public class IlanEkleAktivite extends AppCompatActivity {

    private final String TAG ="IlanEkleAktivite.java";
    private FloatingActionButton goToAddCategory;
    private RelativeLayout AddPhotoWithGalleryContainer;
    private RelativeLayout AddPhotoWithCameraContainer;
    private Bitmap selectedImage;
    private ImageView addPhotoWithGallery;
    private ImageView addPhotoWithCamera;
    public Button saveButton;
    private Animation downtoup;
    private ImageView addPostBackButton;
    private EditText ilkTeklif;

    private FirebaseStorage firebaseStorage;
    private StorageReference storageReference;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseFirestore db2 = FirebaseFirestore.getInstance();
    private FirebaseFirestore db3 = FirebaseFirestore.getInstance();
    private EditText addTitleText;
    private EditText addContentEditText;
    //AktifKullanici aktifKullanici = AktifKullanici.getInstance();
    ActiveUser activeUser = ActiveUser.getInstance();
    private Ilan ilan = new Ilan();
    //private Ilan.Urunler urun = new Ilan.new Urunler();

    //ilan.urun = ilan.new Urunler();
    Uri imageData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_post);
        addPhotoWithGallery = findViewById(R.id.addPhotoWithGallery);
        saveButton = findViewById(R.id.saveButton);
        downtoup = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.downtoup);
        saveButton.setAnimation(downtoup);
        // Floating Action Button Clickable kategori ekle sayfasına gider
        goToAddCategory = findViewById(R.id.floatingActionButtonAddCategory);
        ilkTeklif = findViewById(R.id.ilkTeklif);

        addTitleText = findViewById(R.id.addTitle);
        addContentEditText = findViewById(R.id.addContent);
        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();
        ilan.getUrun().setKategoriId(getIntent().getIntExtra("CATEGORY_ID",0));
        Log.d(TAG,Integer.toString(ilan.getUrun().getKategoriId()));
        ilan.setIlanverenId(activeUser.getId());
        goToAddCategory.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(IlanEkleAktivite.this, KategoriSecAktivite.class);
               startActivity(intent);
           }
        });  //onclick end



        AddPhotoWithGalleryContainer = findViewById(R.id.AddPhotoWithGalleryContainer);
        AddPhotoWithGalleryContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(IlanEkleAktivite.this, "Fotoğraf Ekle Tıklandı", Toast.LENGTH_SHORT).show();
                //todo
                goGallery(v);

            }
        });

        AddPhotoWithCameraContainer = findViewById(R.id.AddPhotoWithCameraContainer);
        AddPhotoWithCameraContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(IlanEkleAktivite.this, "Fotoğraf Çek Tıklandı", Toast.LENGTH_SHORT).show();
                //todo

            }
        });


        addPhotoWithCamera = findViewById(R.id.addPhotoWithCamera);
        addPhotoWithCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent();
                    intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivity(intent);
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
// kaydet butonu


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ilan.getUrun().setAdi(addTitleText.getText().toString());
                ilan.setIcerik(addContentEditText.getText().toString());
                Teklifler e = new Teklifler();
                e.setTeklifVeren(ilan.getIlanverenId());
                e.setFiyat(Double.parseDouble(ilkTeklif.getText().toString()));
                ilan.getTeklifler().add(e);
                //ilan.getTeklifler().put("fiyat", ilkTeklif.getText().toString());

                if (ilan.getUrun().getKategoriId() != 0) {
                    kaydet();
                    //uploadResim();

                    Toast.makeText(IlanEkleAktivite.this, ilan.getUrun().getAdi() + " Kaydedildi", Toast.LENGTH_SHORT).show();
                    //change page
                    Intent intent = new Intent(getApplicationContext(), AnaSayfaAkisAktivite.class);
                    startActivity(intent);
                    //overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                    finish();
                } else
                    Toast.makeText(IlanEkleAktivite.this, "Kategori eklenmedi.", Toast.LENGTH_SHORT).show();


            }
        });




    // geri tuşu

        //todo





    // ilk teklif değeri alınacak







    } // oncreate end


    public void goGallery(View view) {

        // izinlerrrr

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        } else{
            Intent intentToGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intentToGallery,2);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResult){

        if(requestCode == 1){
            if(grantResult.length > 0 && grantResult[0] == PackageManager.PERMISSION_GRANTED){
                Intent intentToGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intentToGallery,2);
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResult);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == 2 && resultCode == RESULT_OK && data !=null){
            Log.d(TAG,"Image Data yuklenmeli");
            imageData = data.getData();
            try {
                if (Build.VERSION.SDK_INT >= 28){
                    ImageDecoder.Source source = ImageDecoder.createSource(this.getContentResolver(),imageData);
                    selectedImage = ImageDecoder.decodeBitmap(source);
                    addPhotoWithGallery.setImageBitmap(selectedImage);
                }else{
                    selectedImage = MediaStore.Images.Media.getBitmap(this.getContentResolver(),imageData);
                    addPhotoWithGallery.setImageBitmap(selectedImage);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            uploadResim();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void uploadResim() {
        if (imageData != null) {
            UUID uuid = UUID.randomUUID();
            String imageName = "images/" + uuid + ".jpg";
            System.out.println("Resim ismi " + imageName);
            storageReference.child(imageName).putFile(imageData).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    //Download URL
                    StorageReference newReference = FirebaseStorage.getInstance().getReference(imageName);
                    newReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            ilan.getUrun().setResim(uri.toString());
                            Log.d(TAG,ilan.getUrun().getResim());
                        }
                    });
                    Toast.makeText(IlanEkleAktivite.this, "Resim başarı ile yüklendi.", Toast.LENGTH_LONG).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(IlanEkleAktivite.this, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

    }
    public void kaydet(){
        HashMap<String, Object> postData = new HashMap<>();
        postData.put("baslik", ilan.urun.getAdi());
        postData.put("icerik", ilan.getIcerik());
        postData.put("ilanverenId", ilan.getIlanverenId());
        ilan.teklifler.get(0).setTeklifVeren(ilan.getIlanverenId());
        ilan.urun.setEkleyen(ilan.getIlanverenId());
        postData.put("baslangic", FieldValue.serverTimestamp());
        postData.put("onay", false);
        postData.put("onaylayanId", "");
        postData.put("bitis", ilan.getBitis());
        db.collection("urunler").add(ilan.urun.getMap()).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                ilan.urun.setId(documentReference.getId());
                postData.put("urunId", ilan.urun.getId());
                db2.collection("ilanlar").add(postData).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference1) {

                        db3.collection("ilanlar").document(documentReference1.getId()).collection("teklifler").add(ilan.teklifler.get(0).getMap()).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                System.out.println("Teklifler : " + ilan.teklifler.get(0).getMap());
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull @NotNull Exception e) {
                                Log.e(TAG, e.getLocalizedMessage());
                            }
                        });
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull @NotNull Exception e) {
                        Log.e(TAG, e.getLocalizedMessage());
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                Log.e(TAG,e.getLocalizedMessage());
            }
        });

        db.collection("urunler").add(ilan.urun.getMap()).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                ilan.getUrun().setId(documentReference.getId());
                postData.put("urunId", ilan.getUrun().getId());
            }
        });

    }
}