package com.e.muzayede;

import android.app.Application;

 import com.jakewharton.threetenabp.AndroidThreeTen;

public class muzayedeApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        //Initialize the timezone information in your Application.onCreate() method
        AndroidThreeTen.init(this);

    }
}