package com.e.muzayede.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.e.muzayede.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class KullaniciListeleAdapter extends RecyclerView.Adapter<KullaniciListeleAdapter.PostHolder> {
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private ArrayList<String> idList;
    private ArrayList<String> kullaniciList;
    private ArrayList<Boolean> kullanici_ilan_List;
    private ArrayList<Boolean> kullanici_yonetici_List;

    public KullaniciListeleAdapter(ArrayList<String> idList, ArrayList<String> kullaniciList, ArrayList<Boolean> kullanici_ilan_List, ArrayList<Boolean> kullanici_yonetici_List) {
        this.idList = idList;
        this.kullaniciList = kullaniciList;
        this.kullanici_ilan_List = kullanici_ilan_List;
        this.kullanici_yonetici_List = kullanici_yonetici_List;
    }

    @NonNull
    @NotNull
    @Override
    public PostHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.row_user, parent, false);
        return new PostHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull PostHolder holder, int position) {
        holder.kullaniciAdi.setText(kullaniciList.get(position));
        holder.switch_ilan.setChecked(kullanici_ilan_List.get(position));
        holder.switch_yonetici.setChecked(kullanici_yonetici_List.get(position));
        holder.switch_ilan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Tiklandi " + String.valueOf(position) + " " + holder.switch_ilan.isChecked());
                toggle(0, position, holder.switch_ilan.isChecked());
            }
        });
        holder.switch_yonetici.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggle(1, position, holder.switch_yonetici.isChecked());
            }
        });
    }

    @Override
    public int getItemCount() {
        return kullanici_ilan_List.size();
    }

    class PostHolder extends RecyclerView.ViewHolder{
        TextView kullaniciAdi;
        Switch switch_ilan, switch_yonetici;

        public PostHolder(@NonNull @NotNull View itemView) {

            super(itemView);
            kullaniciAdi = itemView.findViewById(R.id.kullanici);
            switch_ilan = itemView.findViewById(R.id.switch_ilan);
            switch_yonetici = itemView.findViewById(R.id.switch_yonetici);


        }
    }
    public void toggle(int tur, int pos, boolean durum){
        Long deger=0L;
        if (tur == 0){
            if(durum) {
                deger = 4L;
            } else {
                deger = 2L;
            }

        } else if (tur ==1) {
            if(durum) {
                deger = 16L;
            }
            else {deger = 4L;}
        }
        db.collection("users").document(idList.get(pos)).update("tip", deger).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<Void> task) {
                System.out.println("Ayar degisti");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                System.out.println("Ayar degistirelemedi " + String.valueOf(pos));
            }
        });
    }
}
