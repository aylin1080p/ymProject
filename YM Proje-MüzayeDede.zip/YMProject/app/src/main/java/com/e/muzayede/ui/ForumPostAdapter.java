package com.e.muzayede.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.PopupMenu;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.ActiveUser;
import com.e.muzayede.network.forum.AktifKullanici;
import com.e.muzayede.network.forum.Ilan;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ForumPostAdapter
        extends RecyclerView.Adapter<ForumPostAdapter.PostViewHolder> {

    private List<Ilan> data = new ArrayList<>();
    private LayoutInflater layoutInflater;
    private Context mContex;
    private ActiveUser activeUser = ActiveUser.getInstance();
    private FirebaseFirestore db =FirebaseFirestore.getInstance();
    public ForumPostAdapter(Context context) {
        this.layoutInflater = (LayoutInflater) context.getSystemService(
                Context.LAYOUT_INFLATER_SERVICE);
        this.mContex = context;
    }

    // Provide a reference to the views for each row
    public static class PostViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewPostTitle;
        public TextView textViewAddDate;
        public TextView textViewUserName;
        public TextView textViewLike;
        public TextView textViewMention;
        public TextView textViewicerik;
        public TextView textViewReadMore;
        public CardView feedDesignCardView;
        public TextView textViewFav;


        public ImageView imageViewDate;
        public ImageView imageViewFlag;
        public ImageView imageViewPostPic;
        public ImageView imageViewUser;
        public ImageView imageViewLike;
        public ImageView imageViewMention;
        public ImageView imageViewReadMore;
        public  ImageView imageViewFav;

        public PostViewHolder(@NonNull View view) {
            super(view);
            textViewPostTitle = view.findViewById(R.id.textViewPostTitle);
            textViewAddDate = view.findViewById(R.id.textViewAddDate);
            textViewUserName = view.findViewById(R.id.textViewUserName);
            textViewLike = view.findViewById(R.id.textViewLike);
            textViewMention = view.findViewById(R.id.textViewComment);
            textViewicerik = view.findViewById(R.id.textViewicerik);
            textViewReadMore = view.findViewById(R.id.textViewReadMore);
            feedDesignCardView = view.findViewById(R.id.feedDesignCardView);
            imageViewFav = view.findViewById(R.id.imageViewFav);
            textViewFav = view.findViewById(R.id.textViewFav);

            imageViewDate = view.findViewById(R.id.imageViewDate);
            imageViewFlag = view.findViewById(R.id.imageViewFlag);
            imageViewPostPic = view.findViewById(R.id.imageViewPostPic);
            imageViewUser = view.findViewById(R.id.imageViewUser);
            imageViewLike = view.findViewById(R.id.imageViewLike);
            imageViewMention = view.findViewById(R.id.imageViewComment);
            imageViewReadMore = view.findViewById(R.id.imageViewReadMore);

        }
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View postRow = this.layoutInflater.inflate(
                R.layout.row_post, parent, false);
        return new PostViewHolder(postRow);

    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        //ViewHolder a baglaninca yapilacaklar.
        Ilan currentIlan = data.get(position);
        System.out.println("Holder : " + currentIlan.urun.getResim());
        Picasso.get().load(currentIlan.urun.getResim()).into(holder.imageViewPostPic);
        holder.textViewPostTitle.setText(currentIlan.getBaslik());

        // Post Container Click
        holder.feedDesignCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContex, "open post", Toast.LENGTH_SHORT).show();
                showPost(v, position);
            }
        });


        ////////////////////
        holder.textViewicerik.setText(currentIlan.getIcerik());
        String likeCount = " close skill ";
        holder.textViewLike.setText(likeCount);

        String commentCount =  " Ürünü Gör ";
        holder.textViewMention.setText(commentCount);

       // String favoriteCount = currentPost.getFavoriteCount() + " Son Verilen Teklif";
       //  holder.textViewFav.setText(favoriteCount);

        //holder.textViewAddDate.setText(currentIlan.getDateTime().toString());
        holder.textViewAddDate.setText(currentIlan.getBaslangicStr());
        holder.textViewUserName.setText(currentIlan.getUrun().user.getAdSoyad());
        System.out.println("Holder " + currentIlan.urun.user.getAdSoyad());
        System.out.println("Holder " + currentIlan.getBaslangicStr());
        //System.out.println("Holder " + currentIlan.getBas().toString());

        holder.textViewUserName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(mContex, "kullanıcı adı tıklandı-- kullanıcı sayfasına gidilecek",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(mContex, KullaniciListeleAktivite.class);
                mContex.startActivity(intent);
            }
        });


        holder.textViewicerik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPost(v, position);
                }

        });
        holder.textViewReadMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPost(v, position);
            }
        });

        holder.imageViewFlag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                PopupMenu popUp = new PopupMenu(mContex, view);
                MenuInflater inflater = popUp.getMenuInflater();
                if(Integer.parseInt(activeUser.getTip())>4){
                    inflater.inflate(R.menu.card_menu_admin, popUp.getMenu());
                } else {
                    inflater.inflate(R.menu.card_menu, popUp.getMenu());
                }
                popUp.show();


                popUp.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId()){
                            case R.id.ilanOnayla:
                                Toast.makeText(mContex, "Onayla", Toast.LENGTH_LONG).show();
                                ilanOnayla(position);
                                return true;
                            case R.id.ilanSil:
                                Toast.makeText(mContex, "Sil", Toast.LENGTH_LONG).show();
                                ilanSil(position);
                                return true;
                            case R.id.followThePost:

                                Toast.makeText(mContex, "Gönderi Takip Ediliyor",Toast.LENGTH_LONG).show();
                                return true;
                            case R.id.report:
                                Toast.makeText(mContex, "Gönderiyi Şikayet Et",Toast.LENGTH_LONG).show();
                                return true;
                            case  R.id.falseCategory:
                                Toast.makeText(mContex, "Yanlış Kategori Bildir",Toast.LENGTH_LONG).show();
                                return true;
                            default:
                                return false;
                        }




                    }
                });


            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setData(List<Ilan> data) {
        this.data = data;
        notifyDataSetChanged();
    }


    public void showPost(View view, int position){
        System.out.println("ForumPost id: " + data.get(position).getId() + " position: " +position);
        Intent intent = new Intent(mContex, IlanGosterAktivite.class);
        intent.putExtra("ILAN_ID", data.get(position).getId());
        mContex.startActivity(intent);

    }



    public void ilanSil(int position){
        DocumentReference docRef = db.collection("ilanlar").document(data.get(position).getId());
        docRef.collection("teklifler").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                for (QueryDocumentSnapshot doc: queryDocumentSnapshots){
                    docRef.collection("teklifler").document(doc.getId()).delete();
                }
                db.collection("ilanlar").document(data.get(position).getId()).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(mContex,"Ilan silindi.", Toast.LENGTH_LONG).show();
                        notifyDataSetChanged();
                    }
                });
            }
        });

    }
    public void ilanOnayla(int position){
        db.collection("ilanlar").document(data.get(position).getId()).update("onay", true, "onaylayanId",activeUser.getId()).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(mContex,"Ilan onaylandi.", Toast.LENGTH_LONG).show();
                notifyDataSetChanged();
            }
        });

    }

}