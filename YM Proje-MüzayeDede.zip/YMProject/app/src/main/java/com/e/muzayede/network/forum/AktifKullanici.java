package com.e.muzayede.network.forum;

public class AktifKullanici extends Kullanicilar{
    private static AktifKullanici aktifKullanici;
     private AktifKullanici() {
    }

    public static AktifKullanici getInstance(){
         if(aktifKullanici == null){
             aktifKullanici = new AktifKullanici();
         }
         return aktifKullanici;
    }
}
/*
public class AktifKullanici{
    private static AktifKullanici instance = null;
    private String id;
    private String email;
    private AktifKullanici(){

    }

    public AktifKullanici(String id, String email) {
        this.id = id;
        this.email = email;
    }

    public Boolean olustur(String id, String email) {
        this.id = id;
        this.email = email;
        return  true;
    }

    public Boolean bosOlustur() {
        return true;
    }
    public static AktifKullanici getInstance(){
        if (instance == null){
            instance = new AktifKullanici();
        }
        return instance;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
*/