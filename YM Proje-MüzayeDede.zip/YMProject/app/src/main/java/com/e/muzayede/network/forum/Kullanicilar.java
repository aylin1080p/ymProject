package com.e.muzayede.network.forum;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

public class Kullanicilar {
    private String id;
    private String adSoyad;
    private String email;
    private String telefon;
    private String adres;
    private Long tip;
    private String onaylayan;
    private Boolean aktifMi;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private Boolean donus;

    public Kullanicilar() {
    }

    public Kullanicilar(String id, String adSoyad, String email, String telefon, String adres, Long tip, String onaylayan, Boolean aktifMi) {
        this.id = id;
        this.adSoyad = adSoyad;
        this.email = email;
        this.telefon = telefon;
        this.adres = adres;
        this.tip = tip;
        this.onaylayan = onaylayan;
        this.aktifMi = aktifMi;
    }
    public Boolean bosOlustur(){
        HashMap<String, Object> postData = new HashMap<>();
        postData.put("id", this.id);
        postData.put("adSoyad", this.adSoyad);
        postData.put("email", this.email);
        postData.put("telefon", this.telefon);
        postData.put("adres", this.adres);
        postData.put("tip", this.tip);
        postData.put("aktifMi", false);
        postData.put("onaylayan", this.onaylayan);

        db.collection("users").document(this.id).set(postData).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                donus = true;
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                donus = false;
            }
        });
        return donus;
    }
    public Boolean olustur(String id, String email, String adSoyad){
        this.id = id;
        this.email = email;
        this.adSoyad = adSoyad;
        this.tip = 4L;
        return bosOlustur();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAdSoyad() {
        return adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getAdres() {
        return adres;
    }

    public void setAdres(String adres) {
        this.adres = adres;
    }

    public Long getTip() {
        return tip;
    }

    public String getTipString() {
        if (this.tip ==  null){
            this.tip = -1L;
        }
        return this.tip.toString();
    }

    public int getTipInt() {
        if (this.tip == null) {
            this.tip = -1L;
        }
        return this.tip.intValue();
    }


    public void setTip(Long tip) {
        this.tip = tip;
    }

    public String getOnaylayan() {
        return onaylayan;
    }

    public void setOnaylayan(String onaylayan) {
        this.onaylayan = onaylayan;
    }

    public Boolean getAktifMi() {
        return aktifMi;
    }

    public void setAktifMi(Boolean aktifMi) {
        this.aktifMi = aktifMi;
    }
}
