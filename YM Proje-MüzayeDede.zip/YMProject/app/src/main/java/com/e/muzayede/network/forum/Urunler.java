package com.e.muzayede.network.forum;

import com.google.firebase.firestore.FieldValue;

import java.util.HashMap;
import java.util.Map;

public class Urunler {
    private String id;
    private String adi;
    private int kategoriId;
    private String resim;
    private String ekleyen;
    public Kullanicilar user = new Kullanicilar();


    public Urunler() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public int getKategoriId() {
        return kategoriId;
    }

    public void setKategoriId(int kategoriId) {
        this.kategoriId = kategoriId;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public String getEkleyen() {
        return ekleyen;
    }

    public void setEkleyen(String ekleyen) {
        this.ekleyen = ekleyen;
    }
    public Map<String, Object> getMap(){
        Map<String, Object> sonuc = new HashMap<String, Object>();
        sonuc.put("id", this.id);
        sonuc.put("ekleyen", this.ekleyen);
        sonuc.put("adi", this.adi);
        sonuc.put("kategoriId", this.kategoriId);
        sonuc.put("resim", this.resim);
        return sonuc;
    }
}
