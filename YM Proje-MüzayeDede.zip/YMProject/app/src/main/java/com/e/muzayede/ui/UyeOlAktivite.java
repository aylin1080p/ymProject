package com.e.muzayede.ui;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.AktifKullanici;
import com.e.muzayede.network.forum.Kullanicilar;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

public class UyeOlAktivite extends AppCompatActivity {

    private Button btnLogin,btnSignup,buttonLogin,button3;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private AktifKullanici aktifKullanici = AktifKullanici.getInstance();
    EditText username, password, adSoyad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        btnLogin=(Button) findViewById(R.id.buttonLoginn);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        adSoyad = findViewById(R.id.adSoyad);
        /*btnSignup=(Button)findViewById(R.id.btnSignup);

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });*/

        //button3 Kaydol butonu
        button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   String usernameText = username.getText().toString();
                   String passwordText = password.getText().toString();
                   String adSoyadText = adSoyad.getText().toString();
                   if (usernameText.length() > 0 && passwordText.length() >0 && adSoyadText.length()> 0) {
                       firebaseAuth.createUserWithEmailAndPassword(usernameText, passwordText).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                           @Override
                           public void onSuccess(AuthResult authResult) {
                               FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
                               String userId = firebaseUser.getUid();
                               aktifKullanici.olustur(userId, firebaseUser.getEmail(), adSoyadText);
                               //Kullanicilar user = new Kullanicilar(userId, firebaseUser.getEmail());
                               Toast.makeText(UyeOlAktivite.this, userId + " Kaydınız başarıyla gerçekleşti", Toast.LENGTH_SHORT).show();
                               Intent intent = new Intent(UyeOlAktivite.this, LoginActivity.class);
                               // giriş ekranına yönlendiriliyor kayıttan sonra
                               startActivity(intent);
                           }
                       }).addOnFailureListener(new OnFailureListener() {
                           @Override
                           public void onFailure(@NonNull @NotNull Exception e) {
                               Toast.makeText(UyeOlAktivite.this, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                           }
                       });
                   }
               }
       });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UyeOlAktivite.this, LoginActivity.class);
                startActivity(intent);
            }

        });
    }
}

