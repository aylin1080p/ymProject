package com.e.muzayede.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.e.muzayede.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        // set up main-to-social button
        ImageButton goToSocialActivityButton = findViewById(R.id.changeMainToSocialButton);
        goToSocialActivityButton.setOnClickListener((View v) -> goToSocialActivity());
    }

    private void goToSocialActivity() {
        Intent intent;
        intent = new Intent(this, AnaSayfaAkisAktivite.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        finish();
    }
}