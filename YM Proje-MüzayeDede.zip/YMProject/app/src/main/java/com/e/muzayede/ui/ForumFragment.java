package com.e.muzayede.ui;

import android.content.Intent;
import android.os.Bundle;
// import android.support.v7.widget.LinearLayoutManager;
// import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.ActiveUser;
import com.e.muzayede.network.forum.AktifKullanici;
import com.e.muzayede.network.forum.Kategoriler;
import com.e.muzayede.network.forum.Ilan;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.jetbrains.annotations.NotNull;
import org.threeten.bp.OffsetDateTime;
import org.threeten.bp.ZoneOffset;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class ForumFragment extends Fragment implements ForumCategoryAdapter.ForumCategoryAdapterListener {


    public static final String EXTRA_POST_TYPE = "extra_post_type";
    public static final String TAG = "Forum Fragment";
    private List<Kategoriler> categories = new ArrayList<>();
    private List<Ilan> ilans = new ArrayList<>();
    private ZoneOffset zoneOffset;
    private SearchView forumSearchBar;
    private RecyclerView postRecyclerView;
    private RecyclerView categoryRecyclerView;
    private ForumCategoryAdapter categoryAdapter;
    private ForumPostAdapter postAdapter;
    private RelativeLayout postContainer;
    private RelativeLayout categoryContainer;
    private FloatingActionButton addPostFabButton1;
    private FloatingActionButton addPostFabButton2;
    private FloatingActionButton addPostFabButton3, addPostFabButton4;
    private TextView addPostText1, addPostText2, addPostText3, addPostText4;
    private ConstraintLayout addPostButtonContainer;
    private View forumBackground;
    private FloatingActionButton addPostFabButton;
    private int currentCategoryId = 0;
    private int parentCategoryId = 0;
    private ForumFragmentListener fragmentListener;
    private FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    //private AktifKullanici aktifKullanici = AktifKullanici.getInstance();
    private ActiveUser activeUser = ActiveUser.getInstance();

    public interface ForumFragmentListener {
        void closeSearchBarFromFragment ();
    }


//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String s) {
//                return false;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String s) {
//
//                furnitureAdapter.getFilter().filter(s);
//
//                return false;
//            }
//        });



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_forum, container, false);
        zoneOffset = OffsetDateTime.now().getOffset();
        //generateDummyData();
        getCategories();
        System.out.println("Asama 1 " + categories.size());
        getIlans();
        System.out.println("Asama 2 " + ilans.size());

        // initalize views
        categoryContainer = rootView.findViewById(R.id.categoryContainer);
        postContainer = rootView.findViewById(R.id.postContainer);
        addPostFabButton1 = rootView.findViewById(R.id.addPostFabButton1);
        addPostFabButton2 = rootView.findViewById(R.id.addPostFabButton2);
        addPostFabButton3 = rootView.findViewById(R.id.addPostFabButton3);
        addPostFabButton4 = rootView.findViewById(R.id.addPostFabButton4);
        addPostText1 = rootView.findViewById(R.id.askQues);
        addPostText2 = rootView.findViewById(R.id.postNews);
        addPostText3 = rootView.findViewById(R.id.postInfo);
        addPostButtonContainer = rootView.findViewById(R.id.addPostButtonContainer);
        forumBackground = rootView.findViewById(R.id.forumBackground);

        // add post buttonn*******
        addPostFabButton = rootView.findViewById(R.id.addPostFabButton); //+  butonu
        System.out.println("Asama 3");
        addPostFabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPostButtonContainer.setVisibility(VISIBLE);
                forumBackground.setVisibility(VISIBLE);
                addPostFabButton.setVisibility(GONE);
                kontrolButtons();
            }
        });

        forumBackground.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPostButtonContainer.setVisibility(GONE);
                forumBackground.setVisibility(GONE);
                addPostFabButton.setVisibility(VISIBLE);
            }
        });

        addPostFabButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "açık arttırma ekle tıklandı", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), IlanEkleAktivite.class);
                startActivity(intent);
            }
        });

        addPostFabButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Toast.makeText(getActivity(), "kategori ekle Tıklandı", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), KategoriEkleAktivite.class);
                startActivity(intent);
            }
        });

        addPostFabButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getActivity(), "alt yönetici ekle Tıklandı", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), YoneticiEkleAktivite.class);
                startActivity(intent);

            }
        });

        addPostFabButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getActivity(), "Çıkış Tıklandı.", Toast.LENGTH_SHORT).show();
                firebaseAuth.signOut();
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);

            }
        });


        // initialize search bar and category list
        // forumSearchBar = rootView.findViewById(R.id.forumSearchBar);
        categoryRecyclerView = rootView.findViewById(R.id.forumCategories);

        // to initialize categoryRecyclerView, use a linear layout manager
        RecyclerView.LayoutManager categoryLayoutManager = new LinearLayoutManager(getActivity(),
                LinearLayoutManager.VERTICAL, false);

        // "Set layout manager to position the items"
        categoryRecyclerView.setLayoutManager(categoryLayoutManager);

        // initialize the list adapter
        if (getActivity() != null) {
            categoryAdapter = new ForumCategoryAdapter(getActivity(), categories, this);
            // "Attach the adapter to the recyclerView to populate items"
            categoryRecyclerView.setAdapter(categoryAdapter);
            categoryAdapter.setCurrentData(0);
        }



        // initialize post list
        postRecyclerView = rootView.findViewById(R.id.forumPosts);

        // to initialize postRecyclerView, use a linear layout manager
        RecyclerView.LayoutManager postLayoutManager = new LinearLayoutManager(getActivity(),
                LinearLayoutManager.VERTICAL, false);

        // "Set layout manager to position the items"
        postRecyclerView.setLayoutManager(postLayoutManager);
        // initialize the list adapter
        if (getActivity() != null) {
            postAdapter = new ForumPostAdapter(getActivity());
            // "Attach the adapter to the recyclerView to populate items"
            postRecyclerView.setAdapter(postAdapter);
            postAdapter.setData(ilans);

        }
        return rootView;
    }

    public void showCategoryRecyclerView() {
        categoryContainer.setVisibility(VISIBLE);
        postContainer.setVisibility(GONE);
    }

    public int categoryNavigationGoBack() {
        if (currentCategoryId == 0){
            categoryAdapter.setCurrentData(0);
            categoryContainer.setVisibility(GONE);
            postContainer.setVisibility(VISIBLE);
            return  0;
        } else {
            categoryAdapter.setCurrentData(parentCategoryId);
            currentCategoryId = parentCategoryId;
            parentCategoryId = findParentId(currentCategoryId);
            return 1;
        }
    }

    private int findParentId (int id) {
        for (Kategoriler kategori : categories) {
            if (kategori.getId() == id) {
                return kategori.getUstId();
            }
        }
        return 0;
    }

    private void goToAddPostActivity(int id) {
        Intent intent = new Intent(getActivity(), IlanEkleAktivite.class);
        startActivity(intent);


    }

    @Override
    public void sendCurrentId(int id, int parentId) {
        currentCategoryId = id;
        parentCategoryId = parentId;
    }

    @Override
    public void goToPosts(int id) {
        // categori kapat post aç searchbar kapat
        categoryAdapter.setCurrentData(0);
        categoryContainer.setVisibility(GONE);
        postContainer.setVisibility(VISIBLE);
        fragmentListener.closeSearchBarFromFragment();
        currentCategoryId = 0;
        parentCategoryId = 0;

        // talk to post adapter to filter post
        List<Ilan> filteredIlans = getPostsById(id);
        postAdapter.setData(filteredIlans);
    }

    private List<Ilan> getPostsById(int id) {
        ArrayList<Ilan> res = new ArrayList<>();

        for (Ilan ilan : ilans) {
            if (ilan.getUrun().getKategoriId() == id) {
                res.add(ilan);
            }
        }
        return res;
    }

    public void setForumFragmentListener (ForumFragmentListener listener) {
        this.fragmentListener = listener;
    }

    public void kontrolButtons() {
        //Log.d(TAG, aktifKullanici.getEmail());
        System.out.println("ActiveUser " + activeUser.getId() + " " + activeUser.getId());
        //System.out.println("HOOOP " + aktifKullanici.getEmail() + " tipi: " + aktifKullanici.getTipString());
        try {
            int kullaniciTipi = Integer.parseInt(activeUser.getTip());
            switch (kullaniciTipi){
                case 1:
                    addPostFabButton1.setVisibility(View.INVISIBLE); //Ilan Ekle
                    addPostText1.setVisibility(View.INVISIBLE);
                    addPostFabButton2.setVisibility(View.INVISIBLE); //Kategori Ekle
                    addPostText2.setVisibility(View.INVISIBLE);
                    addPostFabButton3.setVisibility(View.INVISIBLE); //Alt yonetici
                    addPostText3.setVisibility(View.INVISIBLE);
                    System.out.println("Uye olmadan giris");
                    break;
                case 2:
                    addPostFabButton1.setVisibility(View.INVISIBLE); //Ilan Ekle
                    addPostText1.setVisibility(View.INVISIBLE);
                    break;
                case 4:
                    addPostFabButton2.setVisibility(View.INVISIBLE); //Kategori Ekle
                    addPostText2.setVisibility(View.INVISIBLE);
                    addPostFabButton3.setVisibility(View.INVISIBLE); //Alt yonetici
                    addPostText3.setVisibility(View.INVISIBLE);
                    break;
            }
        }  catch (Exception e){
            System.out.println(e);
        }

    }

    public void getCategories() {
        db.collection("categories").orderBy("adi", Query.Direction.ASCENDING).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    for(QueryDocumentSnapshot document: task.getResult()){
                        categories.add(document.toObject(Kategoriler.class));

                    }
                    categoryAdapter.notifyDataSetChanged();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                Log.e(TAG,e.getLocalizedMessage());
            }
        });

    }
    public void getIlans(){
        try {
            db.collection("ilanlar").orderBy("baslik", Query.Direction.ASCENDING).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                @Override
                public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                    ilans.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        ilans.add(doc.toObject(Ilan.class));
                        int i = ilans.size() - 1;
                        ilans.get(i).setId(doc.getId());
                        System.out.println(doc.getData());
                        db.collection("users").document(doc.toObject(Ilan.class).getIlanverenId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    Map<String, Object> data = task.getResult().getData();
                                    System.out.println(data);
                                    ilans.get(i).urun.user.setAdSoyad((String) data.get("adSoyad"));
                                    System.out.println("Ilgili kullanici" + ilans.get(i).getUrun().user.getAdSoyad());
                                }
                                postAdapter.notifyDataSetChanged();
                            }
                        });
                        db.collection("urunler").document(doc.toObject(Ilan.class).getUrunId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    Map<String, Object> data = task.getResult().getData();
                                    ilans.get(i).urun.setResim((String) data.get("resim"));
                                }
                                postAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                    //System.out.println(ilans.size() + " " + ilans.get(0).getBaslik());
                    postAdapter.notifyDataSetChanged();
                    writeIlans();
                }

            });
            postAdapter.notifyDataSetChanged();
        } catch(Exception e){
            System.out.println(e.getLocalizedMessage());
        }

        }

    public void getIlans2(){
        db.collection("ilanlar").orderBy("baslik", Query.Direction.ASCENDING).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    for(QueryDocumentSnapshot doc: task.getResult()){
                        ilans.add(doc.toObject(Ilan.class));
                        //ilans.add(new Ilan())
                        int i = ilans.size()-1;
                        ilans.get(i).setId(doc.getId());
                        System.out.println(doc.getData());
                        db.collection("users").document(doc.toObject(Ilan.class).getIlanverenId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()){
                                    Map<String, Object> data = task.getResult().getData();
                                    ilans.get(i).urun.user.setAdSoyad((String) data.get("adSoyad"));
                                    System.out.println("Ilgili kullanici" + ilans.get(i).getUrun().user.getAdSoyad());
                                }
                                postAdapter.notifyDataSetChanged();
                            }
                        });
                        db.collection("urunler").document(doc.toObject(Ilan.class).getUrunId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                                if(task.isSuccessful()){
                                    Map<String, Object> data = task.getResult().getData();
                                    ilans.get(i).urun.setResim((String) data.get("resim"));
                                }
                                postAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                    //System.out.println(ilans.size() + " " + ilans.get(0).getBaslik());
                    postAdapter.notifyDataSetChanged();
                    writeIlans();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {
                Log.e(TAG, e.getLocalizedMessage());
            }
        });
    }

    public void writeIlans(){
        for(int i=0;i<ilans.size();i++){
            Log.d(TAG,ilans.get(i).getBaslik());
        }
    }

}

