package com.e.muzayede.docs;

public class IconAttributions {

    /*
    * Icons:
    *
    *       freepngs.com ?
    *
    * */
}
