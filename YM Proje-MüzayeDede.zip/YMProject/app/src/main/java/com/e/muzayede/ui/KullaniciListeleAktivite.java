package com.e.muzayede.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.e.muzayede.R;
import com.e.muzayede.network.forum.Kategoriler;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Map;

public class KullaniciListeleAktivite extends AppCompatActivity {
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private int tip;
    private boolean sonuc;
    KullaniciListeleAdapter kullaniciListeleAdapter;
    ArrayList<String> idList = new ArrayList<>();
    ArrayList<String> kullanici_List = new ArrayList<>();
    ArrayList<Boolean> kullanici_ilan_List = new ArrayList<>();
    ArrayList<Boolean> kullanici_yonetici_List = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kullanici_listele);
        kullaniciYukle();
        RecyclerView recyclerView = findViewById(R.id.rv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        kullaniciListeleAdapter = new KullaniciListeleAdapter(idList, kullanici_List, kullanici_ilan_List, kullanici_yonetici_List);
        recyclerView.setAdapter(kullaniciListeleAdapter);
    }
    public void kullaniciYukle(){
        db.collection("users").orderBy("adSoyad", Query.Direction.ASCENDING).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Map<String, Object> data = document.getData();
                        idList.add((String) data.get("id"));
                        kullanici_List.add((String) data.get("adSoyad"));
                        Long tipL =  (Long) data.get("tip");
                        tip =  tipL.intValue();
                        if(tip > 2){
                            sonuc = true;
                        } else { sonuc= false;}
                        kullanici_ilan_List.add(sonuc);
                        if(tip > 4){
                            sonuc = true;
                        } else {sonuc =false;}
                        kullanici_yonetici_List.add(sonuc);
                        System.out.println("Kullanicilar " + (String) data.get("adSoyad"));
                        kullaniciListeleAdapter.notifyDataSetChanged();
                    }
                }
            }
        });
    }
}