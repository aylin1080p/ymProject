package com.e.muzayede.network.forum;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class Kategoriler {
    private final static String TAG="Kategoriler.java";
    private int id;
    private String adi;
    private int ustId;
    private String tamAdi;
    private String aciklama;
    private int resimId;
    private boolean sonCocuk;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseFirestore db2;

    public Kategoriler() {
    }

    public Kategoriler(int id, String adi, int ustId, String tamAdi, String aciklama, int resimId, boolean sonCocuk) {
        this.id = id;
        this.adi = adi;
        this.ustId = ustId;
        this.tamAdi = tamAdi;
        this.aciklama = aciklama;
        this.resimId = resimId;
        this.sonCocuk = sonCocuk;
    }


    public Boolean olustur() {
        HashMap<String, Object> postData = new HashMap<>();
        postData.put("id", this.id);
        postData.put("adi", this.adi);
        postData.put("ustId", this.ustId);
        postData.put("tamAdi", this.tamAdi);
        postData.put("resimId", this.resimId);
        postData.put("sonCocuk", this.sonCocuk);
        db.collection("categories").orderBy("id", Query.Direction.DESCENDING).limit(1).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Long Lid = (Long) document.get("id");
                        postData.put("id", Lid.intValue() + 1);
                        Log.d("Kategoriler", Lid.toString());

                    }
                    db2 = FirebaseFirestore.getInstance();
                    db.collection("categories").add(postData).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentReference> task) {
                            //Kategori basari ile yeni idsi ile olusturulmustur.
                            Log.d("Kategoriler", "Yeni kategori yaratilmis.");
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.d("Kategoriler", "Yeni kategori YARATILMAMIS.");
                        }
                    });
                }
            }
        });
        return false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public int getUstId() {
        return ustId;
    }

    public void setUstId(int ustId) {
        this.ustId = ustId;
    }

    public String getTamAdi() {
        return tamAdi;
    }

    public void setTamAdi(String tamAdi) {
        this.tamAdi = tamAdi;
    }

    public String getAciklama() {
        return aciklama;
    }

    public void setAciklama(String aciklama) {
        this.aciklama = aciklama;
    }

    public int getResimId() {
        return resimId;
    }

    public void setResimId(int resimId) {
        this.resimId = resimId;
    }

    public boolean isSonCocuk() {
        return sonCocuk;
    }

    public void setSonCocuk(boolean sonCocuk) {
        this.sonCocuk = sonCocuk;
    }
}